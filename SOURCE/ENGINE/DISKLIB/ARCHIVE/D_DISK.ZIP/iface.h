/*
 *  iface.h     d_disk demo interface definitions
 *
 *  This file is part of the D_DISK library.
 *  Copyright (C) 1998, Gregg Jennings.
 *
 *  See D_DISK.HTM for the library specifications.
 *  See D_DISK.TXT for overview the implementation.
 *  See NOTES.TXT for particulars about the source files.
 *
 */

#if defined __BORLANDC__ && !defined __MSC
#error This code requires -D__MSC on the command line for Borland.
#endif

#include <conio.h>
#if defined __BORLANDC__
#include <graphics.h>
#endif
#if (defined _MSC_VER && !defined _WIN32) || defined __WATCOMC__
#include <graph.h>
#endif

#if defined _WIN32
#define _settextcolor   settextcolor
#define _outtext        outtext
#define _cgets          cgets
void outtext(char *str);
void settextcolor(int color);
void wcgets(char *buf);
#endif

#if defined __BORLANDC__ || defined __GNUC__
#define _settextcolor   textcolor
#define _outtext        cprintf
#define _cgets          cgets
#endif

#if defined __WATCOMC__
#define _cgets          cgets
#endif

enum VIDEO_COLORS {
   Black, Blue, Green, Cyan, Red, Magenta, Brown, White, Gray,
   LtBlue, LtGreen, LtCyan, LtRed, LtMagenta, Yellow, ItWhite
};

#if 0
#define FOREGROUND_BLUE      0x0001 /* text color contains blue. */
#define FOREGROUND_GREEN     0x0002 /* text color contains green. */
#define FOREGROUND_RED       0x0004 /* text color contains red. */
#define FOREGROUND_INTENSITY 0x0008 /* text color is intensified. */
#define BACKGROUND_BLUE      0x0010 /* background color contains blue. */
#define BACKGROUND_GREEN     0x0020 /* background color contains green. */
#define BACKGROUND_RED       0x0040 /* background color contains red. */
#define BACKGROUND_INTENSITY 0x0080 /* background color is intensified. */
#define White (FOREGROUND_RED|FOREGROUND_GREEN|FOREGROUND_BLUE)
#endif

#define INSZ 40

#ifndef NDEBUG
#define BADSTR "\n keyboard + monkey = %s"
#else
#define BADSTR "\n %s huh?"
#endif
