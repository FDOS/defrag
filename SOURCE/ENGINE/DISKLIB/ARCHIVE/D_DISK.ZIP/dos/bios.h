/*
 *	dos\bios.h  INT 13h functions
 *
 *  This file is part of the D_DISK library.
 *  Copyright (C) 1998, Gregg Jennings.
 *
 *  See D_DISK.HTM for the library specifications.
 *  See D_DISK.TXT for overview the implementation.
 *  See NOTES.TXT for particulars about the source files.
 */

extern int disk_get_physical(int disk,int *t,int *s,int *h);
extern int disk_read_p(int disk,unsigned int trk,unsigned int sec,unsigned int head,void *buf,int nsecs,int secsiz);
extern int disk_write_p(int disk,unsigned int trk,unsigned int sec,unsigned int head,void *buf,int nsecs,int secsiz);
extern const char *disk_error(int error);
