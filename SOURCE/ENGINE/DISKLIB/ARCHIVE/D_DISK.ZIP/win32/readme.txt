D_DISK -- A POSIX-like DISK I/O library for non-Unix OSs

WIN32\README.TXT, 29-Nov-1998

Copyright (C) 1998, Gregg Jennings

See D_DISK.HTM for the library specifications.
See D_DISK.TXT for overview the implementation.
See CHANGELOG.TXT for the latest changes.
See also my DISKLIB library documentation.


I am now developing D_DISK to use my DISKLIB library and the source
files here, except for DISKGET.C, are no longer going to be updated.

However, there are subtle differences between DISKLIB and the library
functions here.

I still have yet to write some real documentation. For now, you will
have to go over the makefiles and the sources that have the #ifdef
DISKLIB macros (..\D_DISK.C
