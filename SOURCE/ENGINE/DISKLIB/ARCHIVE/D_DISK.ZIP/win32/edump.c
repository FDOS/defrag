/*
 *  edump.c     display WIN32 error number
 *
 *  This file is part of the D_DISK library.
 *  Copyright (C) 1998, Gregg Jennings.
 *
 *  See D_DISK.HTM for the library specifications.
 *  See D_DISK.TXT for overview the implementation.
 *  See NOTES.TXT for particulars about the source files.
 *
 */

#include <stdio.h>
#include "win32.h"

void err_dump(const char *str)
{
    if (str)
        fprintf(stderr,"%s, ",str);
    fprintf(stderr,"error: %ld\n",GetLastError());
}
