/*
 *  win32\conio.c       console I/O functions
 *
 *  This file is part of the D_DISK library.
 *  Copyright (C) 1998, Gregg Jennings.
 *
 *  See D_DISK.HTM for the library specifications.
 *  See D_DISK.TXT for overview the implementation.
 *  See NOTES.TXT for particulars about the source files.
 *
 */

#include "win32.h"

void *stdout = NULL,*stdin = NULL;

void outtext(char *str)
{
unsigned long tmp;

    if (!stdout)
        stdout = GetStdHandle(STD_OUTPUT_HANDLE);

    WriteConsole(stdout,str,strlen(str),&tmp,NULL);
}

void settextcolor(int color)
{
    if (!stdout)
        stdout = GetStdHandle(STD_OUTPUT_HANDLE);

    SetConsoleTextAttribute(stdout,(unsigned short)color);
}
