/***
*int2f.h -  MSDOS multiple interrupt interface
*
*this file is part of DISKED
*Copyright (c) 1991-1998, Gregg Jennings.  All rights reserved.
*   P O Box 200, Falmouth, MA 02541-0200
*
*Purpose:
*   Error messages.
*
*Notice:
*   This program can be distributed only in accordance with, and
*   accompanied by, the DPU Software License. See COPYING.TXT or,
*   <http://www.diskwarez.com/dpu.htm>.
*******************************************************************************/

extern UINT16 int2f(UINT16);
extern int winver(void);

#ifdef __WATCOMC__
#pragma aux int2f =  \
   "int 2fh"         \
   parm [ax];
#endif
