/***
*files.h - definitions/declarations for file indexing functions.
*
*this file is part of DISKED
*Copyright (c) 1991-1998, Gregg Jennings.  All rights reserved.
*   P O Box 200, Falmouth, MA 02541-0200
*
*Purpose:
*   See FILES.C.
*
*Notice:
*   This program can be distributed only in accordance with, and
*   accompanied by, the DPU Software License. See COPYING.TXT or,
*   <http://www.diskwarez.com/dpu.htm>.
*******************************************************************************/

/*
   Versions

   1.1   15-Dec-1994    removed functions (see ARRAYS.C)
*/

#ifndef GENERAL_H
#include "general.h"
#endif

#define FILE_LEN  13

struct files_t {
     char name[FILE_LEN];
     char dir;
     int parent;
};

extern int ft_track;
extern struct files_t __huge *files;
extern unsigned int n_files,n_dirs;    /* number of files and directories */
extern int __huge *clusters;           /* pointer to array of cluster entries */

extern int initfiles(void);
extern int pfile(char *file,unsigned int i);
extern char *gfile(unsigned int i);
extern int printfile(unsigned int);
extern unsigned findfile(char *file);
extern unsigned int get_avail_clusters(void);
extern void mapfat12(int sec);
