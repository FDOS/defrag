| DISKED About the Source Code
| Version: 3.2.3
| Date: 02-Jul-1998


0. This is a ANOTHER major upgrade. See the file CHANGELO.TXT in
   the sources archive for a low-down of all the major changes.
   This text is just an overview of what you'll be getting into if
   you get the sources.

1. The code is now DJGPP as well as Microsoft and Watcom compatible.

2. The code is hardly ideal. In fact, quite messy. It was first
   developed on a 4Mhz XT machine and I used every trick in the
   book to get speed. Back then using printf to display the
   sector contents was horribly slow. Believe me I wish that I
   had done things differently. I am paying the price now of
   having to re-write most of the code.

   Here are some highlights of the problem areas (other than
   design flaws):

      o  Lack of const qualifiers on strings where there should be.
      o  Many mis-matches of signed/unsigned conditionals.
      o  Many mis-matches (none critical) of int and short.

   Switching to a 32-bit compiler (i.e DJGPP) helped in finding
   many of the latter two.

3. I have made a few poor design choices during the first few
   years and am stuck with them. I let the interface get
   extremely convoluted and downright confusing, codewise.

4. I learned the DOS file system and hard drive topologies by
   trial and error. And were there trials and errors. There were
   literally no good references available 10 years ago, and a
   few bad references.

5. I did do a few things right. Creating the index of all the
   files on a drive is as fast as any other program that locates
   every file on the disk, if not faster than any other. And it
   takes minimal memory. Again I learned how to do it totally on
   my own. I had not a single program or code snippet to compare
   with at the time I implemented it. It don't look pretty, but
   that code is solid.

6. I am happy to say that for 10 years working with DISKED I have
   never damaged any disk. Until last week that is (28-Nov-1997),
   when I trashed the root directory of my C: drive. Two things
   caused this to happen. Faulty code which wrote past the end of
   an array which buggered the pointer to the sector buffer, and
   my not seeing that the sector buffer had been corrupted due to
   my just displaying the first 128 bytes.

   Note that DISKED did not trash my drive, I did. DISKED corrupted
   the sector buffer, but I pressed the key to write the buffer to
   the disk.

--
