/***
*direct.h - function declarations for directory handling.
*
*this file is part of DISKED
*Copyright (c) 1991-1998, Gregg Jennings.  All rights reserved.
*   P O Box 200, Falmouth, MA 02541-0200
*
*Purpose:
*  This include file contains the function declarations for the
*  functions related to directory handling.
*
*Notice:
*   This program can be distributed only in accordance with, and
*   accompanied by, the DPU Software License. See COPYING.TXT or,
*   <http://www.diskwarez.com/dpu.htm>.
*******************************************************************************/

#ifndef GENERAL_H
#include "general.h"
#endif

#ifndef DIRENT_H
#include "dirent.h"
#endif

extern UINT32 cwdstart(void);
extern int file_start(char *file);
extern long file_size(char *file);
extern int direntry(char *name, DOSDIR *dir);
extern int _dos_xfcb_find(DOSEXTFCB *xfcb);
extern void *_dos_getdta(void);
extern void get_volume(int drv, char *v);
