#include <stdlib.h>
#include <string.h>
#include <direct.h>

#include <dir.h>
#include <dos.h>

#include "dirent.h"


extern void get_volume(int drv, char *v)
{
int i,d;
struct _find_t fi;
char cwd[_MAX_DIR];

   d = getdisk();
   setdisk(drv-1);

   if (_getcwd(cwd,_MAX_DIR))          /* get current directory */
   {
      _chdir("\\");                    /* set root directory */
      if (_dos_findfirst("*.*",_A_VOLID,&fi) == 0)
      {
         for (i = 0; i < FILELEN+2; i++)        /* copy all but the '.' */
         {
            if (fi.name[i] != '.' && i <= FILELEN)
               *v++ = fi.name[i];
            if (fi.name[i] == '\0')             /* stop, a NUL! */
               break;
         }
      }
      _chdir(cwd);
   }

   setdisk(d);
}
